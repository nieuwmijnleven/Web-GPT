---
name: Diagnostic Flow
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0edec'
  surface-container-high: '#ebe7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#3c494c'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#6c797c'
  outline-variant: '#bbc9cc'
  surface-tint: '#006876'
  primary: '#006876'
  on-primary: '#ffffff'
  primary-container: '#00bcd4'
  on-primary-container: '#004650'
  inverse-primary: '#44d8f1'
  secondary: '#9a25ae'
  on-secondary: '#ffffff'
  secondary-container: '#ed76fd'
  on-secondary-container: '#69007a'
  tertiary: '#006e1c'
  on-tertiary: '#ffffff'
  tertiary-container: '#5dc05f'
  on-tertiary-container: '#004b10'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a1efff'
  primary-fixed-dim: '#44d8f1'
  on-primary-fixed: '#001f25'
  on-primary-fixed-variant: '#004e59'
  secondary-fixed: '#ffd6fe'
  secondary-fixed-dim: '#f9abff'
  on-secondary-fixed: '#35003f'
  on-secondary-fixed-variant: '#7b008f'
  tertiary-fixed: '#94f990'
  tertiary-fixed-dim: '#78dc77'
  on-tertiary-fixed: '#002204'
  on-tertiary-fixed-variant: '#005313'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  headline-lg:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  gutter: 16px
  margin: 16px
  card-padding: 20px
  touch-target-min: 48px
---

## Brand & Style

This design system establishes a professional, analytical environment for real-time data observation and stream debugging. The brand personality is grounded, precise, and systematic, favoring functional clarity over decorative flair. 

The design style is **Corporate / Modern** with a lean toward **Minimalism**. It utilizes a structured high-contrast approach to status signaling, ensuring that critical data points (like stream insertions or errors) are immediately identifiable against a clean, light background. This light-mode transition improves visibility in well-lit workspaces while maintaining the refined aesthetic of high-end developer tools. The goal is to evoke a sense of reliability and expert control.

## Colors

The palette is anchored in a light-mode architecture to prioritize clarity and precision during technical observation.

- **Primary (Observation Active):** Cyan (#00BCD4) is used for active states, primary actions, and "live" stream indicators.
- **Secondary (User Confirmed):** Purple (#9C27B0) distinguishes user-validated data points from automated detections.
- **Success/Normal:** Green (#4CAF50) signifies healthy data flow and successful operations.
- **Warning (Suspected Insertion):** Orange (#FF9800) captures attention for anomalies that require review.
- **Error/Danger:** Red (#F44336) is reserved for critical failures and destructive reset actions.
- **Pending/Neutral:** Gray (#9E9E9E) identifies data awaiting judgment or inactive states.
- **Surface Strategy:** The base layer uses a neutral off-white derived from #121212, while elevated containers and cards use subtle tonal variations to provide depth without heavy reliance on traditional shadows.

## Typography

The typography system prioritizes legibility for technical logs and structured data. 

- **Primary Sans (Geist):** Used for the core UI, headers, and body text. Its clean, geometric profile ensures a modern, professional feel.
- **Monospaced (JetBrains Mono):** Critical for timestamps, session IDs, and log entries. The monospaced nature allows for easy vertical scanning of changing list data.
- **Scale:** Keep hierarchy strict. Labels for badges and statuses should always be in uppercase Monospaced to differentiate them from interactive UI elements.

## Layout & Spacing

This design system utilizes a **fluid grid** optimized for high-density information display on Android devices. 

- **Rhythm:** An 8px base grid governs all dimensions.
- **Margins:** A standard 16px outer margin ensures content doesn't hit the screen edges.
- **Density:** While being a professional tool, the layout maintains "comfortable density." Cards should be separated by 12px or 16px gutters to ensure clear visual separation of list items.
- **Mobile Adaptivity:** On mobile, the layout is strictly single-column for the feed to maximize horizontal space for log details. On tablets or landscape orientations, a side-rail or split-view is used to show the session list alongside the active log.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** rather than heavy shadows, optimized for light mode.

- **Level 0 (Base):** The primary background color. Used for the background of the entire app.
- **Level 1 (Cards/Surfaces):** A slightly darker or tinted neutral. Used for the primary content containers.
- **Level 2 (Dialogs/Menus):** A distinct surface with a very soft, high-diffusion shadow (0px 4px 20px rgba(0,0,0,0.1)) to separate transient UI from the main stream.
- **Interaction:** On press, cards should use a subtle background color shift (darken by 4%) or a primary-colored stroke to indicate focus.

## Shapes

The shape language follows Material Design 3 guidelines but skews toward a professional feel.

- **Standard Containers:** Use a 16px radius (`rounded-lg`) for main data cards and modal sheets.
- **Small Elements:** Buttons and Input fields use an 8px radius (`rounded-md`).
- **Status Badges:** Use a fully pill-shaped radius to distinguish them from interactive buttons.

## Components

### Buttons & Inputs
- **Primary Action:** Solid Cyan (#00BCD4) background with high-contrast text. 
- **Ghost Buttons:** Cyan or Purple outlines for secondary actions like "View Details."
- **Inputs:** Light neutral background with a 1px border. The border glows Cyan when focused.

### State Badges (Chips)
- Status badges are essential. They should use a low-opacity background of their respective status color (e.g., 15% Orange for "Suspected Insertion") with a high-contrast solid text/icon on top.

### Cards
- Each card represents a "Session" or a "Detection Event." Cards must have a clear vertical color-bar on the left edge corresponding to their current status (Active, Warning, Error) to allow for quick peripheral scanning.

### Specialized Components
- **Detection Feed:** A vertical timeline view with connected nodes.
- **Log Item:** A compact, monospaced text row with a timestamp. Alternating row highlights (zebra striping) should be very subtle to assist line-following.
- **Session Switcher:** A bottom-anchored navigation bar using unique, non-branded icons: a "radar" icon for Detection, a "user-gear" for Profile, and a "layers" icon for Sessions.